### Devflix con técnicas de CSS Avanzado

* Agregar devflix
* Agregar animaciones
* Agregar viewport y mediaqueries
* Agregar responsive a nav
* Agregar off canvas