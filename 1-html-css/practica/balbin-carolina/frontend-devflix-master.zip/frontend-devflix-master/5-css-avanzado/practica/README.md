## Ejercicio Propuesto: Semana 3

### Instrucciones:
Sobre el ejercicio realizado en la Semana 1, hacer los siguientes cambios en la web:

1. Utilizar linear-gradient de background para el nav
2. Configurar el viewport para que tenga el ancho del dispositivo, la escala inicial debe ser 1.0 y la escala máxima del doble
3. Cambiar la barra de navegación con media queries para que se visualice correctamente en mobile (480px), se puede incluir jquery para la manipulación del DOM
4. Cambiar la cantidad de imágenes a 2 por fila en mobile (480px)

Enlaces de apoyo:
* [Windows Resizer](https://chrome.google.com/webstore/detail/window-resizer/kkelicaakdanhinjdeammmilcgefonfh): Extensión de Chrome para emular distintas resoluciones de pantalla