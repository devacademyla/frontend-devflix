### Devflix con Frameworks y Librerías de Frontend

* Agregar base para bootstrap
* Usar Bootstrap y el sistema de grillas
* Usar Bootstrap en devflix
* Utilizar jquery
* Agregar Angular.js
* Usar ng-repeat y clases dinámicas
* Usar ng-repeat con series
* Agregar buscador
* Sistema de Tabs
* Refactor Sistema de Tabs