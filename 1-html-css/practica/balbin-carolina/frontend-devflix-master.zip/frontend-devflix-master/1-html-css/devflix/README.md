### Devflix con HTML5 y CSS3

* Estructurar directorios
* Maquetar index con HTML5
* Agregar assets a la maqueta
* Agregar clases y referencia a estilos.css
* Agregar estilos