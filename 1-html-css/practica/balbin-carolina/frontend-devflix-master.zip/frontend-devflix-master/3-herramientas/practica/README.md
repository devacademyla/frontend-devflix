## Ejercicio Propuesto: Semana 2

### Instrucciones:
Sobre el ejercicio realizado en la Semana 1, hacer lo siguiente:

1. Minificar CSS
2. Agregar soporte a navegadores antiguos (HTML5Shiv, Modernizr, PrefixFree, entre otros)
3. Agregar soporte a multiples navegadores con prefijos propietarios (webkit, ms, entre otros) a las propiedades CSS que lo necesiten
4. Agregar un screenshot de la página en Internet Explorer 8

Enlaces de apoyo:
* [caniuse.com](http://caniuse.com/): Comparar el soporte de propiedades en los navegadores
* [modernizr.com](http://modernizr.com/)
* [IETester](http://www.my-debugbar.com/wiki/IETester/HomePage): Ejecuta proyectos web en todas las versiones de IE
* [browserstack.com](http://www.browserstack.com/): Ejecuta proyectos web en distintos navegadores